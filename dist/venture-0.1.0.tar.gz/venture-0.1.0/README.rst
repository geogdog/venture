Venture
=======

A project management tool that will create skeleton code to get you going quickly.  It will also help you manage your pojects in a sane way.
